<center><h2>Web Forms</h2>
<a href="#gallery">[Sign Gallery]</a></center>
<br>
<br>

<a id="gallery"><h4>Sign Gallery</h4></a>
<p>This link has the images used for the Zodiac signs as thumbnails. Click thumbnail images to see the image in full size.</p>
<a href="ZodiacGallery.php">[Test the Script]</a>
<a href="ShowSourceCode.php?source_file=ZodiacGallery.php">[View the code]</a>
<br>
<br>