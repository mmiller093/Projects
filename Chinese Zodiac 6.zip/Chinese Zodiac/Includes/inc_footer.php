<?php
echo"<br><br>";
echo file('proverbs.txt')[rand(0, count(file('proverbs.txt'))-1)];
echo"<br><br>";
$folder = scandir('Images/');

function checkImageIsDragon($image) {
	return preg_match('/^Dragon\d+\.(gif|jpg|png)$/', $image);
}

$folder = array_filter($folder, "checkImageIsDragon");
echo "<img src=\"Images/".$folder[array_rand($folder)]."\">";
echo"<br><br>";
echo "&#9400 2017";

