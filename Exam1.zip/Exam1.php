<html>
<head>
<title>EXAM 1 Login Form</title>
<h1>Login</h1>
</head>
<body>
<?php
if (isset($_POST["name"])) { // check if form submitted (username input exists)
	$isvalid=true;
	// form was submitted
	if (preg_match("/./", $_POST["name"])) {
		echo "<p style=\"color: green;\">&#x2713: Passed! Username field nonempty</p>";
	} else {
		echo "<p style=\"color: red;\">&#128405: Failed! Username field empty</p>"; // middle finger (Just thought it was funny to find that 																				   unicode)
		$isvalid=false;
	}

	if (preg_match("/[0-9]{1,}/", $_POST["pass"])) {
		echo "<p style=\"color: green;\">&#x2713: Passed! Contains atleast one number</p>";
	} else {
		echo "<p style=\"color: red;\">&#x2718: Failed! Must contain atleast one number</p>";
		$isvalid=false;
	}

	if (preg_match("/[a-z]{1,}/", $_POST["pass"])) {
		echo "<p style=\"color: green;\">&#x2713: Passed! Contains atleast one lowercase letter</p>";
	} else {
		echo "<p style=\"color: red;\">&#x2718: Failed! Must contain atleast one lowercase letter</p>";
		$isvalid=false;
	}

	if (preg_match("/[A-Z]{1,}/", $_POST["pass"])) {
		echo "<p style=\"color: green;\">&#x2713: Passed! Contains atleast one uppercase letter</p>";
	} else {
		echo "<p style=\"color: red;\">&#x2718: Failed! Must contain atleast one uppercase letter</p>";
		$isvalid=false;
	}

	if (preg_match("/^\S+$/", $_POST["pass"])) {
		echo "<p style=\"color: green;\">&#x2713:Passed! Contains no spaces</p>";
	} else {
		echo "<p style=\"color: red;\">&#x2718: Failed! Must contain no spaces</p>";
		$isvalid=false;
	}

	if (preg_match("/^.{8,16}$/", $_POST["pass"])) {
		echo "<p style=\"color: green;\">&#x2713: Passed! Must be 8 - 16 characters long</p>";
	} else {
		echo "<p style=\"color: red;\">&#x2718: Failed! Must 8 - 16 characters long</p>";
		$isvalid=false;
	}

	if (preg_match("/[^a-zA-Z\d]/", $_POST["pass"])) {
		echo "<p style=\"color: green;\">&#x2713: Passed! Contains a non letter and/or number</p>";
	} else {
		echo "<p style=\"color: red;\">&#x2718: Failed! Must contain a non letter and/or number</p>";
		$isvalid=false;
	}  

	if ($isvalid) {
		echo "Password Hash: ", password_hash($_POST["pass"], PASSWORD_DEFAULT);// print success message, password hash
		echo "</body></html>";
		die(); // dont output anything else
	}
}
?>
<form action="" method="post">
	<input name="name" type="text" placeholder="Username" value="<?php
	if (isset($_POST["name"])) {
		echo $_POST["name"];
		} ?>">
	<input name="pass" type="password" placeholder="Password"></br></br>
	<input type="submit">
</form>
</body>
</html>