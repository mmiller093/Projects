<html>
<head>
</head>
<body>
<p>
<a href="PHP">[PHP]</a>
<a href="ChineseZodiac">[Chinese Zodiac]</a>	
</body>
</html>