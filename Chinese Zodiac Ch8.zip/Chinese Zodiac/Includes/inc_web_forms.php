<center><h2>Web Forms</h2>
<a href="#gallery">[Sign Gallery]</a>
<a href="#addFeedback">[Add Feedback]</a>
<a href="#viewFeedback">[View Feedback]</a></center>
<br>
<br>

<a id="gallery"><h4>Sign Gallery</h4></a>
<p>This link has the images used for the Zodiac signs as thumbnails. Click thumbnail images to see the image in full size.</p>
<a href="ZodiacGallery.php">[Test the Script]</a>
<a href="ShowSourceCode.php?source_file=ZodiacGallery.php">[View the code]</a>
<br>
<br>
<a id="addFeedback"><h4>Add Feedback</h4></a>
<p>This link will allow the user to add feedback for the website</p>
<a href="zodiac_feedback.html">[Test the Script]</a>
<a href="ShowSourceCode.php?source_file=zodiac_feedback.html">[View the code]</a>
<br>
<br>
<a id="viewFeedback"><h4>View Feedback</h4></a>
<p>This link will allow the user to view the feedback that was marked to be public from the Add Feedback link.</p>
<a href="view_zodiac_feedback.php">[Test the Script]</a>
<a href="ShowSourceCode.php?source_file=view_zodiac_feedback.php">[View the code]</a>