
<a href="index.php?page=home_page">
<img class="btn" src="Images/HomePage.gif" alt="[Home Page]" title="Home Page" style="border:0" /></a><br />

<a href="index.php?page=site_layout">
<img class="btn" src="Images/SiteLayout.gif" alt="[Site Layout]" title="Site Layout" style="border:0" /></a><br />

<a href="index.php?page=control_structures">
<img class="btn" src="Images/ControlStructures.gif" alt="[Control Structures]" title="Control Structures" style="border:0" /></a><br />

<a href="index.php?page=string_funtions">
<img class="btn" src="Images/StringFunctions.gif" alt="[String Functions]" title="String Functions" style="border:0" /></a><br />

<a href="index.php?page=web_forms">
<img class="btn" src="Images/WebForms.gif" alt="[Web Forms]" title="Web Forms" style="border:0" /></a><br />

<a href="index.php?page=midterm_assessment">
<img class="btn" src="Images/MidtermAssessment.gif" alt="[Midterm Assessment]" title="Midterm Assessment" style="border:0" /></a><br />

<a href="index.php?page=state_information">
<img class="btn" src="Images/StateInformation.gif" alt="[State Information]" title="State Information" style="border:0" /></a><br />

<a href="index.php?page=user_templates">
<img class="btn" src="Images/UserTemplates.gif" alt="[User Templates]" title="User Templates" style="border:0" /></a><br />

<a href="index.php?page=final_project">
<img class="btn" src="Images/FinalProject.gif" alt="[Final Project]" title="Final Project" style="border:0" /></a><br />