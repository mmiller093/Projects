<?php
echo"<br><br>";
echo file('proverbs.txt')[rand(0, count(file('proverbs.txt'))-1)];
?>